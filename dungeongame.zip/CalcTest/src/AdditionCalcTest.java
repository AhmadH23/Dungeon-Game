import static org.junit.Assert.*;

import org.junit.Test;

public class AdditionCalcTest {

	@Test
	public void testAddition() {
		//fail("Not yet implemented");
		int output = CalcTest.addition(9,9);
		assertEquals(18,output);
	}
	@Test
	public void testAddition1() {
		//fail("Not yet implemented");
		int output = CalcTest.addition(1234,5678);
		assertEquals(6912,output);
	}
	@Test
	public void testMinus() {
		int output = CalcTest.minus(10, 9);
		assertTrue(1 == output);
	}
	@Test
	public void testDivide() {
		int output = CalcTest.divide(10, 2);
		assertNotEquals(2, output);
	}
	@Test
	public void testMultiply() {
		//fail("Not yet implemented");
		int output = CalcTest.multiply(9,9);
		assertFalse(81 != output);
	}
	

}
