import static org.junit.Assert.*;

import org.junit.Test;

public class MultiplyCalcTest {

	@Test
	public void testMultiply() {
		//fail("Not yet implemented");
		int output = CalcTest.multiply(9,9);
		assertEquals(81,output);
	}
	@Test
	public void testMultiply1() {
		//fail("Not yet implemented");
		int output = CalcTest.multiply(9,100);
		assertEquals(900,output);
	}
	@Test
	public void testMultiply2() {
		//fail("Not yet implemented");
		int output = CalcTest.multiply(9,3);
		assertEquals(27,output);
	}
	@Test
	public void testMinus() {
		int output = CalcTest.minus(6, 2);
		assertSame(4, output);
				
	}
	@Test
	public void testMinus1() {
		int output = CalcTest.minus(6, 2);
		assertNotSame(5, output);
				
	}
}
