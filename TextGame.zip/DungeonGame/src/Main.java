import java.util.Random;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		// scanner and random for objects in game
		Scanner in = new Scanner(System.in);
		Random rand = new Random();
		
		// variables for the game for enemies
		
		String [] enemies = {"Troll", "Vampire", "Zombie", "Skeleton"};
		int maxEnemyHealth = 80;
		int enemyAttackDamage = 27;
		
		// variables for player
		
		int health = 100;
		int attackDamage = 32;
		int numHealthPotions = 3;
		int healthPotionHealAmount = 35;
		int healthPotionDropChance = 30; // i.e 30 percent chance that potion will drop
		
		boolean running = true;
		
		System.out.println("Welcome to the Dungeon!");
		
		GAME: //label, will iterate back to here when running
		
		while (running) {
			System.out.println("--------------------------------------");
			
			int enemyHealth = rand.nextInt(maxEnemyHealth); // random number for enemy health
			String enemy = enemies[rand.nextInt(enemies.length)];
			System.out.println("\t# " + enemy + " has appeared!  #\n"); // using \t to indent and format to look neat when running
			
			while (enemyHealth > 0) {
				System.out.println("\tYour HP: " + health);
				System.out.println("\t" + enemy + "'s HP: " + enemyHealth);
				System.out.println("\n\tWhat would you like to do?");
				System.out.println("\t1. Attack");
				System.out.println("\t2. Drink health potion");
				System.out.println("\t3. Run!!");
				
				String input = in.nextLine();
				if(input.equals("1")) {
					int damageDealt = rand.nextInt(attackDamage);
					int damageTaken = rand.nextInt(enemyAttackDamage);
					
					enemyHealth -= damageDealt;
					health -= damageTaken;
					
					System.out.println("\t> You attack the " + enemy + " for " + damageDealt + " damage.");
					System.out.println("\t> You took " + damageTaken + " in retaliation!");
					
					if(health < 1) {
						System.out.println("\t> You have taken too much damage :(");
						break; // this will break out of while loop and continue below 
					}
				} 
				else if(input.equals("2")) {
					if(numHealthPotions > 0) {
						health += healthPotionHealAmount;
						numHealthPotions--;
						System.out.println("\t> You drink a health potion healing yourself for " + healthPotionHealAmount + "."
										 + "\n\t> You now have " + health + " HP!"
										 + "\n\t> You have " + numHealthPotions + " health potions left.\n");
					}
					else {
						System.out.println("\t> You have no health potions left, defeat enemies for a chance to get one!");
					}
				}
				else if(input.equals("3")) {
					System.out.println("\tYou have run away from " + enemy + "!");
					continue GAME; // will go back to GAME loop
				}
				else {
					System.out.println("\tInvalid command");
					
				}
				
				
			}
			
			if(health < 1) {
				System.out.println("You crawl out of the dungeon, weak from battle.");
				break;
			} 
			
			System.out.println("--------------------------------------");
			System.out.println(" * " + enemy + " was defeated! *");
			System.out.println(" * You have " + health + " HP left. *");
			if(rand.nextInt(100) < healthPotionDropChance);{ // using this for a chance to drop a health potion
				numHealthPotions++;
				System.out.println(" * The " + enemy + " dropped a health potion! * ");
				System.out.println(" * You now have " + numHealthPotions + " health potion(s). * ");
		}
		System.out.println("--------------------------------------");
		System.out.println("What would you like to do now?");
		System.out.println("1. Continue fighting!");
		System.out.println("2. Exit dungeon.");
		
		String input = in.nextLine();
		
		while (!input.equals("1") && !input.equals("2")) {
			System.out.println("Invalid command");
			input = in.nextLine();
		}
		if(input.equals("1")) {
			System.out.println("You continue on your adventure");
		}
		else if (input.equals("2")) {
			System.out.println("You exit the dungeon successfully!");
			break;
		}
	}
		
		System.out.println("***************************");
		System.out.println(" * THANK YOU FOR PLAYING! *");
		System.out.println("***************************");

}
}


